//
//  VMRPacketFlippedView.h
//  ViewMaster
//
//  Created by Robert England on 3/12/15.
//  Copyright (c) 2015 Robert England. All rights reserved.
//
//  Abstract: Displays the back of the packet, along with a link to eBay.
//

#import <UIKit/UIKit.h>
#import "VMRPacketView.h"
@class VMRPacket;
@class VMRPacketViewController;

@interface VMRPacketFlippedView : VMRPacketView

@end
