//
//  VMRPacketViewController.h
//  ViewMaster
//
//  Created by Robert England on 3/12/15.
//  Copyright (c) 2015 Robert England. All rights reserved.
//
//  Abstract: Controller that manages the full size tile view of the packet,
//     including creating the reflection and flipping the tile.
//

#import <UIKit/UIKit.h>

//@class VMRPacket;

@interface VMRPacketViewController : UIViewController

@property (nonatomic, strong) VMRPacket *myPacket;

- (void)flipCurrentView;

@end
