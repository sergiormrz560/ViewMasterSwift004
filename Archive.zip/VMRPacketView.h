//
//  VMRPacketView.h
//  ViewMaster
//
//  Created by Robert England on 3/12/15.
//  Copyright (c) 2015 Robert England. All rights reserved.
//
//  Abstract: Displays the packet information in a large format tile.
//
#import <UIKit/UIKit.h>

@class VMRPacket;
@class VMRPacketViewController;

@interface VMRPacketView : UIView

@property (nonatomic, strong) VMRPacket *packet;
@property (nonatomic, strong) VMRPacketViewController *viewController;

+ (CGSize)preferredViewSize;
- (UIImage *)reflectedImageRepresentationWithHeight:(NSInteger)height;

@end
