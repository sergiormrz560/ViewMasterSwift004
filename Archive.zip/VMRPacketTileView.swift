//
//  VMRPacketTileView.swift
//  ViewMasterSwift
//
//  Created by Robert England on 6/2/15.
//  Copyright (c) 2015 Robert England. All rights reserved.
//
//  Description: VIEW: Draws the small tile view of a packet displayed in a tableview row.
//

import UIKit

class VMRPacketTileView: UIView {
    var packet : VMRPacket
    
    override init(frame aRect: CGRect) {
        packet = VMRPacket()
        super.init(frame: aRect)
    }

    required init (coder aDecoder: NSCoder) {
        packet = VMRPacket()
        super.init(coder: aDecoder)
    }


    override func drawRect(rect: CGRect) {
        let tileImage = packet.imageForPacketTileView()
        let tileImageRectangle = CGRectMake(0, 0, tileImage!.size.width, tileImage!.size.height)
        tileImage?.drawInRect(tileImageRectangle)
    }
}
